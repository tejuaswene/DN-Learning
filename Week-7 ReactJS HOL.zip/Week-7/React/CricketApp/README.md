# CricketApp
This React app demonstrates ES6 features including map, arrow functions, destructuring, and conditional rendering.